﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

	public Transform target;
	public float dampTime = 0.15f;
	public float minDist = 0.1f;
	private Vector3 velocity = Vector3.zero;
    private Vector3 lastPos = Vector2.zero;

	// Update is called once per frame
	void LateUpdate () 
	{
        if (target)
        {
            Vector3 targetVelocity = (target.transform.position - lastPos);
            lastPos = target.transform.position;
            if (Vector2.Distance(
                new Vector2(
                    transform.position.x,
                    transform.position.y
                    )
                ,
                new Vector2(
                    target.transform.position.x,
                    target.transform.position.y
                    )
                ) > minDist)
            {
                transform.Translate(targetVelocity);
            }
        }
	}
}
