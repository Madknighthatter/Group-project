﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarpScript : MonoBehaviour {

    public static string globalSceneTag; //Static string to store scene tag
    public string spawnTag; //Acts as unique tag and also the name for the scene
    public string sceneTo; //The scene to go to

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            WarpScript.globalSceneTag = spawnTag;
            Application.LoadLevel(sceneTo);
        }
    }
}
