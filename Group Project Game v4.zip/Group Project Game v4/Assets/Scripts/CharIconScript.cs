﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharIconScript : MonoBehaviour {

	public int charId;
	public bool selected;
	public Sprite sprite_m;
	public Sprite sprite_f;

	public int energy,skill,social,money;
	public GameObject showSelected;
	public string name;

	private CharSelectScript css;
	private SpriteRenderer renderer;

	void Start()
	{
		css = GameObject.FindGameObjectsWithTag("CharacterSelector")[0].GetComponent<CharSelectScript>();
		renderer = GetComponent<SpriteRenderer> ();
		showSelected.active = false;
	}

	void Update()
	{
		if (css.charId == charId)
			selected = true;
		else
			selected = false;
		
		showSelected.active = selected;
		if (selected) 
		{
			if (css.isMale)
				renderer.sprite = sprite_m;
			else
				renderer.sprite = sprite_f;
		}
	}
}
