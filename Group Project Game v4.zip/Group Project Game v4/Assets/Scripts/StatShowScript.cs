﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatShowScript : MonoBehaviour {

	public List<GameObject> stars;
	public int amount;

	void Start()
	{
		for (int i = 0; i < stars.Count; i++) 
		{
			stars[i].active = false;
		}
	}

	public void ChangeAmount(int _amount)
	{
		amount = _amount;
		for (int i = 0; i < stars.Count; i++) 
		{
			stars[i].active = (i < amount);
		}
	}
}
