﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextBoxScript : MonoBehaviour {

	public static Text textObject;
	private float time = 0.0f;

	// Use this for initialization
	void Start () 
	{
		textObject = GameObject.FindGameObjectsWithTag ("TextBoxText") [0].GetComponent<Text>();
	}

	void Update()
	{
		gameObject.GetComponent<Image> ().enabled = (textObject.text != "");
		textObject.enabled = (textObject.text != "");

		if (textObject.text != "") {
			time += Time.deltaTime;
			if (time > 3.0f)
				textObject.text = "";
		} else
			time = 0.0f;

	}
	
	public static void SetText(string text)
	{
		textObject.text = text;
	}
}
