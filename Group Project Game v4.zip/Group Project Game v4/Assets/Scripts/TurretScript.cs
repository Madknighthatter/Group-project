﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretScript : MonoBehaviour {

	public float rotateSpeed;
	public GameObject spawnPoint;
	public GameObject world;
	public GameObject bulletPrefab;
	public GameObject turretPrefab;
	public float speed;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		float amount = Input.GetAxisRaw ("Horizontal");
		transform.Rotate (0.0f, 0.0f, -amount * rotateSpeed * Time.deltaTime);

		if (Input.GetKeyDown ("space")) 
		{
			GameObject bullet = Instantiate (bulletPrefab);
			bullet.transform.position = Vector3.zero;
			bullet.GetComponent<Rigidbody2D> ().velocity = Vector3.MoveTowards (bullet.transform.position, spawnPoint.transform.position,speed) ;
			bullet.transform.position = spawnPoint.transform.position;
		}
	}
}
