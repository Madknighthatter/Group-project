﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharSelectScript : MonoBehaviour {

	public int charId;
	public int noOfCharacters;
	public GameObject energyObject;
	public GameObject skillObject;
	public GameObject socialObject;
	public GameObject moneyObject;
	public Text nameObject;
	public bool isMale;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (noOfCharacters != 0) 
		{
			if (Input.GetKeyDown ("right"))
				charId++;
			else if (Input.GetKeyDown ("left"))
				charId--;

			charId = ((charId+noOfCharacters) % noOfCharacters);

			if (Input.GetKeyDown ("up") || Input.GetKeyDown ("down"))
				isMale = !isMale;
		}

		if (Input.GetKeyDown ("return"))
			GotoScene ();

		foreach (GameObject g in GameObject.FindGameObjectsWithTag("CharacterIcon")) 
		{
			CharIconScript script = g.GetComponent<CharIconScript> ();
			if (script.selected) 
			{
				energyObject.GetComponent<StatShowScript> ().ChangeAmount (script.energy+TraitScript.energy);
				skillObject.GetComponent<StatShowScript> ().ChangeAmount (script.skill+TraitScript.skill);
				socialObject.GetComponent<StatShowScript> ().ChangeAmount (script.social+TraitScript.social);
				moneyObject.GetComponent<StatShowScript> ().ChangeAmount (script.money+TraitScript.money);
				nameObject.text = script.name + (isMale ? " (M)" : " (F)");

				CharacterStatsScript.energy = script.energy;
				CharacterStatsScript.skill = script.skill;
				CharacterStatsScript.social = script.social;
				CharacterStatsScript.money = script.money;
			}
		}
	}

	public void GotoScene()
	{
		Application.LoadLevel ("test");
	}
}
