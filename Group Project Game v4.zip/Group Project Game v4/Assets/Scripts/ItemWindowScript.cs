﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemWindowScript : MonoBehaviour {

	public GameObject buttonPrefab;
	public GameObject ScrollRect;
	public List<GameObject> buttons = new List<GameObject>();

	// Use this for initialization
	void Start () {
		UpdateButtons ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void UpdateButtons()
	{
		//Clear previous buttons
		foreach (GameObject g in buttons) 
		{
			Destroy (g);
		}
		buttons.Clear ();

		//Create buttons
		for (int i = 0; i < Inventory.items.Count; i++) 
		{
			GameObject obj = Instantiate (buttonPrefab);
			buttons.Add (obj.gameObject);
			obj.transform.SetParent (ScrollRect.transform, false);
			obj.GetComponent<RectTransform> ().anchoredPosition = new Vector2 (0, -30*i);

		}

	}
}
