﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TraitScript : MonoBehaviour {

	public List<Sprite> traitSprites;
	public int traitId;
	public static int energy;
	public static int skill;
	public static int social;
	public static int money;
	public string name;
	public Text textObject;
	private bool changedTrait = false;

	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown ("space")) 
		{
			traitId = (traitId+1) % traitSprites.Count;
			GetComponent<Image> ().sprite = traitSprites [traitId];
			changedTrait = true;
		}

		energy = 0;skill = 0;social = 0;money = 0;
		switch (traitId) 
		{
		case 0:
			{name = "None";break;}
		case 1:
			{name = "Deep Sleeper";energy = -1;break;}
		case 2:
			{name = "Gym goer";energy = 1;break;}
		case 3:
			{name = "Instrument";social = 1;break;}
		case 4:
			{name = "Part-time job";money = 1;energy = -1;break;}
		case 5:
			{name = "Doting parents";money = 1;break;}
		case 6:
			{name = "Codemaster";skill = 1;social = -1;break;}
		case 7:
			{name = "Night Owl";energy = 1;break;}
		case 8:
			{name = "Social Butterfly";social = 2;energy = -1;break;}
		default:
			{name = "None";break;}
		}

		if (changedTrait)
			textObject.text = name;
	}


}
