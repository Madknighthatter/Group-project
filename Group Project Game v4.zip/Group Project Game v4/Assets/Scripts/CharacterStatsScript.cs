﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStatsScript : MonoBehaviour {

	/*
	 * This object will contain all the stats of the
	 * player such as energy, money, gender etc.
	 * 
	 * These are static numbers, so for example if you need to change their sociability, use:
	 * CharacterStatsScript.social = 3;
	 * Items are contained somehwere else
	*/

	public static int energy, skill, social, money;
	public static bool isMale;

	// Use this for initialization
	void Start () 
	{
		DontDestroyOnLoad (gameObject);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
