﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlashingEffect : MonoBehaviour {

	public bool isflashing;
	private float flashTime = 0.0f;
	private SpriteRenderer renderer;

	// Use this for initialization
	void Start () 
	{
		renderer = GetComponent <SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (isflashing) 
		{
			flashTime = 1.0f;
			isflashing = false;
		}

		GameObject cam = GameObject.FindGameObjectWithTag ("MainCamera");
		if (flashTime > 0) {
			renderer.color = Color.Lerp (Color.black, Color.red, Mathf.Sin (flashTime * 25.0f));
			flashTime -= Time.deltaTime;
			if (flashTime > 0.75f)
				cam.transform.position = Random.insideUnitSphere* 0.2f + new Vector3(0.0f,0.0f,-10.0f);
			else
				cam.transform.position = new Vector3 (0.0f, 0.0f, -10.0f);
		} else {
			renderer.color = Color.white;
		}
	}
}
