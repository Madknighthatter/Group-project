﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WorldScript : MonoBehaviour {

	private FlashingEffect fScript;
	public GameObject turret;
	public GameObject virusPrefab;
	public Text wwwText;
	public float spawnRate;
	private float time = 0f;
	public int health = 4;
	private static GameObject player;

	// Use this for initialization
	void Start () 
	{
		fScript = GetComponent<FlashingEffect> ();
		player = GameObject.FindGameObjectWithTag ("Player");

	}

	void Update()
	{
		if (GameObject.Find("Player"))
			player.transform.position = new Vector3 (1000f, 0f, 0f);
		time += Time.deltaTime;
		if (time > spawnRate)
		{
			GameObject virus = Instantiate (virusPrefab);
			float angle = Random.Range (0f, Mathf.PI * 2);
			virus.transform.position = new Vector2 (Mathf.Cos (angle), -Mathf.Sin (angle)) * 5f;
			time = 0f;
		}
	}
	
	public void GetHit()
	{
		fScript.isflashing = true;
		turret.GetComponent<FlashingEffect> ().isflashing = true;
		health--;
		if (health == 3)
			wwwText.text = "www";
		else if (health == 2)
			wwwText.text = "ww";
		else if (health == 1)
			wwwText.text = "w";
		else if (health == 0) {
			WorldScript.GoBack ();
		}

	}

	public static void GoBack()
	{
		player.active = true;
		Application.LoadLevel ("test2");
	}
}
