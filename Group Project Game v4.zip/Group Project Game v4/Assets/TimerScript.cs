﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerScript : MonoBehaviour {

	private int timer = 30;
	private float dt = 0f;
	private Text myText;
	private GameObject player;

	void Start()
	{
		myText = GetComponent<Text> ();
	}

	// Update is called once per frame
	void Update () {
		dt += Time.deltaTime;
		if (dt >= 1f) 
		{
			dt = 0f;
			timer--;
			myText.text = timer.ToString ();
			if (timer == 0) 
			{
				WorldScript.GoBack ();
			}
		}
	}
}
