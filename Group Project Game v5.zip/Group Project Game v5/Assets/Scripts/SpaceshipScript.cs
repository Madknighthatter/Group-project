﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceshipScript : MonoBehaviour {

	public GameObject explosionPrefab;
	private bool exploded = false;

	void Update()
	{
		if (Input.GetKeyDown ("g"))
			Explode ();
	}
	public void Explode()
	{
		if (!exploded) {
			GameObject explosion = Instantiate (explosionPrefab);
			explosion.transform.position = transform.position;
			GameObject.FindGameObjectWithTag ("computerScreen").GetComponent<ComputerScreenScript> ().Error ();
			transform.position = new Vector3 (1000f, 0.0f, 0.0f);
			exploded = true;
		}
	}
}
