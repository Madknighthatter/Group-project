﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarsScript : MonoBehaviour {

	public float minX;
	public float speed;
	private float xStart;
	private float newX;

	// Use this for initialization
	void Start () {
		xStart = transform.position.x;
		newX = xStart;
	}
	
	// Update is called once per frame
	void Update () 
	{
		newX -= speed * Time.deltaTime;
		if (newX < minX)
			newX = xStart;
		transform.position = new Vector3 (newX, transform.position.y, transform.position.z);
	}
}
