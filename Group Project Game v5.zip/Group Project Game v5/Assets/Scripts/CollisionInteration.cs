﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CollisionInteration : MonoBehaviour {
	public string[] text;
	int number = 0;
	bool isTalking = false;
	float coolDown = 0.5f;

	// Use this for initialization

	// Update is called once per frame
	void Update () 
	{
		coolDown -= Time.deltaTime;
		if (isTalking) {

			TextBoxScript.time = 0.0f;
			TextBoxScript.SetText (text[number]);

			if (coolDown <= 0 && Input.GetKeyDown (KeyCode.Space)) 
			{
				number++;
				if (number >= text.Length) 
				{
					isTalking = false;
					TextBoxScript.SetText ("");

				}
				coolDown = 0.5f;
			}

		} else
			number = 0;
	}

	void OnTriggerStay2D(Collider2D coll)
	{
		//if player comes in contact with character.
		if (coll.transform.tag == "Player" && coolDown <= 0)
		{
			if (Input.GetKeyDown(KeyCode.Space) && !isTalking)
			{
				//To set text use this line!
				number = 0;
				isTalking = true;

				coolDown = 0.5f;
			}
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.transform.tag == "Player") {
			GameObject.FindGameObjectWithTag ("pressSpace").transform.position = transform.position + new Vector3 (0f, 0.2f, 0f);
		}
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if (col.transform.tag == "Player") {
			isTalking = false;
			GameObject.FindGameObjectWithTag ("pressSpace").transform.position = new Vector3 (-10000f, 0f, 0f);
		}
	}




}
