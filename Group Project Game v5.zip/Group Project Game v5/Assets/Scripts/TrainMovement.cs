﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrainMovement : MonoBehaviour {

	public float speed;
	public float wrap;
	private float xStart;
	private float x = 0;

	void Start()
	{
		xStart = transform.position.x;
	}
	
	// Update is called once per frame
	void Update () {

		x += speed * Time.deltaTime;
		float newX = x % wrap + xStart;
		transform.position = new Vector3 (newX, transform.position.y, transform.position.z);
	}
}
