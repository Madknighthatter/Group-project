﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ComputerScreenScript : MonoBehaviour {

	public float timer = 0.5f;
	public bool exploded;
	public Sprite errorSprite;
	private SpriteRenderer renderer;

	// Use this for initialization
	void Start () {
		renderer = GetComponent<SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		//Short delay before error
		if (exploded) 
		{
			timer -= Time.deltaTime;
			if (timer < 0) 
			{
				exploded = false;
				renderer.sprite = errorSprite;
			}
		}
	}

	public void Error()
	{
		//The spaceship has exploded
		exploded = true;
	}
}
