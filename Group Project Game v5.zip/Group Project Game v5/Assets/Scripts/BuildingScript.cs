﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingScript : MonoBehaviour {

	public GameObject signPost;

	void Start()
	{
		signPost.active = false;
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.tag == "Player")
			signPost.active = true;
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if (col.tag == "Player")
			signPost.active = false;
	}
}
