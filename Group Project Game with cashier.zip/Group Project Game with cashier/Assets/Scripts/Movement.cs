﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

	public float walkSpeed;
	public Vector2 inputDirection;
	private Rigidbody2D rbody2D;
	private Animator animator;

	// Use this for initialization
	void Start () 
	{
		rbody2D = GetComponent<Rigidbody2D> ();
		animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {

		float horizontal = Input.GetAxisRaw ("Horizontal");
		float vertical = Input.GetAxisRaw ("Vertical");
		if (horizontal != 0 || vertical != 0) 
		{
			animator.SetBool ("moving", true);
			animator.SetFloat ("MoveX", horizontal);
			animator.SetFloat ("MoveY", vertical);
			if (horizontal != 0) 
			{
				animator.SetFloat ("LastMoveX", horizontal);
				animator.SetFloat ("LastMoveY", 0);
			}
			if (vertical != 0) 
			{
				animator.SetFloat ("LastMoveY", vertical);
				animator.SetFloat ("LastMoveX", 0);
			}
		}
		else
			animator.SetBool ("moving", false);	

		inputDirection = new Vector2 (horizontal, vertical);
		rbody2D.velocity = inputDirection * walkSpeed;
	}
}
