﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnScript : MonoBehaviour {

    // Use this for initialization
    public string spawnTag;
	void Awake ()
    {
        GameObject player = GameObject.FindGameObjectsWithTag("Player")[0];
        if (player)
        {
            if (WarpScript.globalSceneTag == spawnTag)
                player.transform.position = transform.position;
        }
	}

}
