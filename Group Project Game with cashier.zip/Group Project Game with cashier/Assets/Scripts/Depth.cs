﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Depth : MonoBehaviour {

	private SpriteRenderer renderer;

	// Update is called once per frame
	void Update () {
		float amount = 0.01f;
		transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.y * amount);
	}
}
