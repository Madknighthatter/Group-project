﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour {

	/*
	 * The player presses B to open the inventory and from there can select an item
	 * by using the up/down keys on a UI and pressing A.
	 */

	public static List<Item> items = new List<Item>();
	public int maxItems = 10;
	public GameObject InventoryMenu;
	public int selectId = 0;
	private bool canScroll = false;
	private float lastTime = 0.0f;

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		var inventory = InventoryMenu.GetComponent<ItemWindowScript> ();
		if (Input.GetKeyDown ("g")) 
		{
			
			items.Add (new Item ("hello " + items.Count));
			inventory.UpdateButtons ();
		}

		if (true) //Only true if attention given to inventory
		{
			canScroll = (Time.time > lastTime + 0.25f);
			if (Input.GetAxisRaw ("Vertical") != 0 && canScroll) 
			{
				selectId -= Mathf.FloorToInt (Input.GetAxisRaw ("Vertical"));
				lastTime = Time.time;
			}

			foreach (GameObject g in inventory.buttons) 
			{
				g.GetComponent<ButtonScript> ().ToggleOff ();
			}

			if (selectId < 0)
				selectId = 0;
			if (selectId > inventory.buttons.Count-1 )
				selectId = inventory.buttons.Count-1;
			
			if (selectId != -1) {
				inventory.buttons [selectId].GetComponent<ButtonScript> ().ToggleOn ();
				Debug.Log (inventory.buttons [selectId]);
			}
			
		}

	}
}

public struct Item
{
	public Item(string _name){name = _name;}
	public string name;

}