﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScenePreserve : MonoBehaviour {

    public static bool exists = false;

    void Awake()
    {
        if (exists)
            Destroy(gameObject);
    }

    void Start()
    {
        
        DontDestroyOnLoad(transform.gameObject);
        exists = true;
    }
}
